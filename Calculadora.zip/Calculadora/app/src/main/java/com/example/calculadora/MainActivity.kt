package com.example.calculadora

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    /* 0 ->nada
    *1->suma
    * 2-> resta
    * 3 -> multi![
    * 4 -> divi
    * */
    var operacion: Int = 0
    var numero: Int = 0
    lateinit var resultadoTextView: TextView
    lateinit var Historial : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        resultadoTextView = findViewById(R.id.resultadoTextView)
        Historial = findViewById(R.id.Historial)
        val btnBorrar :Button = findViewById(R.id.button_c)
        val btnIgual :  Button = findViewById(R.id.botonigual)

        btnIgual.setOnClickListener {
            var numero1 : Int = resultadoTextView.text.toString().toInt()
            var resp : Int = 0


            when(operacion){
                1 -> resp = numero + numero1
                2 -> resp = numero - numero1
                3 -> resp = numero * numero1
                4 -> resp = numero / numero1

            }

            resultadoTextView.setText(resp.toString())
            Historial.setText("")

        }

        btnBorrar.setOnClickListener{
            resultadoTextView.setText("")
            Historial.setText("")
            numero = 0
            operacion = 0
        }


    }

    fun presionarDigito(view: View) {

        var num2: String = resultadoTextView.text.toString()

        when (view.id) {
            R.id.boton0 -> resultadoTextView.setText(num2 + " 0")
            R.id.boton1 -> resultadoTextView.setText(num2 + "1")
            R.id.boton2 -> resultadoTextView.setText(num2 + "2")
            R.id.boton3 -> resultadoTextView.setText(num2 + "3")
            R.id.boton4 -> resultadoTextView.setText(num2 + "4")
            R.id.boton5 -> resultadoTextView.setText(num2 + "5")
            R.id.boton6 -> resultadoTextView.setText(num2 + "6")
            R.id.boton7 -> resultadoTextView.setText(num2 + "7")
            R.id.boton8 -> resultadoTextView.setText(num2 + "8")
            R.id.boton9 -> resultadoTextView.setText(num2 + "9")
            R.id.botonpunto -> resultadoTextView.setText(num2 + ".")
        }
    }


    fun clicOperacion(view: View) {
        numero = resultadoTextView.text.toString().toInt()
        var num2_text: String = resultadoTextView.text.toString()
        Historial.setText("")

        when (view.id) {
            R.id.botonsuma -> {
                Historial.setText(num2_text + "+")
                operacion = 1
            }
            R.id.botonresta -> {
                Historial.setText(num2_text + "-")
                operacion = 2
            }
            R.id.botonMultiplicacion -> {
                Historial.setText(num2_text + "x")
                operacion = 3
            }
            R.id.botonDivi -> {
                Historial.setText(num2_text + "÷")
                operacion = 4
            }


        }
    }
}
